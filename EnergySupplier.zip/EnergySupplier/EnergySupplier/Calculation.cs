﻿using EnergySupplier.Models;
using Newtonsoft.Json;
using System.Data;

namespace EnergySupplier
{
    public static class Calculation
    {
        public static List<Result> results = null;
        public static List<Result> finalResults = new List<Result>();
        public static List<string> AnnualCostListDetails(string path, List<int> costs)
        {

            var schemaModelDetails = CovertJsonToModel(path);
            foreach (var annualCost in costs)
            {
                results = new List<Result>();
                foreach (var schema in schemaModelDetails)
                {
                    Calulate(schema, annualCost);
                }
                finalResults.AddRange(results.OrderBy(a => a.Cost).ToList());
            }
            return finalResults.Select(a => a.Details).ToList();
        }

        private static void Calulate(Root Schema, int annualCost)
        {
            var priceList = Schema.Prices.ToList();
            double cost = 0;
            foreach (var price in priceList)
            {
                if (annualCost > 0)
                {
                    if (price.Threshold == 0)
                    {
                        cost += price.Rate * annualCost;
                        annualCost = 0;
                    }
                    else
                    {
                        cost += price.Threshold * price.Rate;
                        annualCost -= price.Threshold;
                    }

                }

            }
            if (Schema.Standing_charge.HasValue && Schema.Standing_charge > 0)
            {
                cost += Schema.Standing_charge.Value * 365;
            }
            var vat = cost * 5 / 100;
            var costWithvat = (vat + cost) / 100;
            var finalCost = Math.Round(costWithvat, 2);
            results.Add(new Result()
            {
                Cost = finalCost,
                Details = Schema.Supplier_name + " ," + Schema.Plan_name + " ," + finalCost
            });

        }

        private static List<Root>? CovertJsonToModel(string path)
        {
            try
            {
                if (!File.Exists(path))
                {
                    path = "../../../config.json";
                }
                using (StreamReader r = new StreamReader(path))
                {
                    string json = r.ReadToEnd();

                    var items = JsonConvert.DeserializeObject<List<Root>>(json);
                    return items;
                }
            }
            catch
            {
                return null;
            }
        }
    }
}

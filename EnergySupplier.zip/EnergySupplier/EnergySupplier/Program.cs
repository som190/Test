﻿using EnergySupplier;

namespace MyApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            string path = string.Empty;
            var annualCostList = new List<int>();
            Console.WriteLine("Input: ");
            path = Console.ReadLine();

            do
            {
                Console.WriteLine("annual_cost ");
                var data = Console.ReadLine();
                if (!string.IsNullOrEmpty(data) && int.TryParse(data, out int res))
                {
                    annualCostList.Add(res);
                }
            }
            while (Console.ReadLine() != "exit");

           
            if (!string.IsNullOrEmpty(path) && annualCostList.Any())
            {
                AnnualCostList(path, annualCostList);
            }
           
        }

        public static void AnnualCostList(string path, List<int> costs)
        {
           var annualCostList = Calculation.AnnualCostListDetails(path, costs);

            foreach (var item in annualCostList)
            {
                Console.WriteLine(item);
            }
        }
    }
}
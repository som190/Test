﻿namespace EnergySupplier.Models
{
    public class Price
    {
        public double Rate { get; set; }
        public int Threshold { get; set; }
    }
}

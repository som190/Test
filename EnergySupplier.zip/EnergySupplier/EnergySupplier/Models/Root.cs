﻿namespace EnergySupplier.Models
{
    public class Root
    {
        public string Supplier_name { get; set; }
        public string Plan_name { get; set; }
        public List<Price> Prices { get; set; }
        public int? Standing_charge { get; set; }
    }
}
